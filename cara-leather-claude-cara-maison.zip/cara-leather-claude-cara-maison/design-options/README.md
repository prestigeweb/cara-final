# Design directions

Three homepage directions for review, in one page with a switcher at the top:
`index.html`.

| | Idea | Palette | Type |
|---|---|---|---|
| **01 Spec** | The manufacturing drawing as the luxury object — indexed, ruled, annotated | Cool paper `#E9E9E4`, ink, blueprint steel `#3E5C76` | Archivo + IBM Plex Mono |
| **02 Vitrine** | The display case after hours, lit from above | Warm black `#14100D`, aged brass `#B08D57`, bone | Bodoni Moda + Jost |
| **03 Maison** | The stock leather palette becomes the layout | Forest, oxblood, navy, bone | Fraunces + Schibsted Grotesk |

Each direction also solves the same real problem a different way: every product
shot in the Drive is on a white studio ground. Spec drops that white into the
paper with `mix-blend-mode: multiply`; Vitrine turns it into a lit panel on the
dark ground; Maison sets it in bone panels riding across the colour bands.

These are comps, not production code — the shipped site lives in `src/`.

## Previewing locally

Image paths are relative (`products/…`), so serve this directory with the
product images beside it:

```bash
ln -s ../public/products design-options/products   # once, not committed
npx serve design-options
```
