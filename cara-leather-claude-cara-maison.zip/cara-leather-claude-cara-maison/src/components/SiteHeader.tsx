"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Wordmark from "./Wordmark";
import { getDict } from "@/i18n/dictionaries";
import type { Lang } from "@/lib/products";

export default function SiteHeader({ lang }: { lang: Lang }) {
  const t = getDict(lang);
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  // Close the mobile drawer whenever the route changes.
  useEffect(() => setOpen(false), [pathname]);

  const other: Lang = lang === "en" ? "ar" : "en";
  // Swap only the leading language segment, keep the rest of the path.
  const otherHref = pathname.replace(/^\/(en|ar)/, `/${other}`) || `/${other}`;

  const links = [
    { href: `/${lang}/collections`, label: t.nav.collections },
    { href: `/${lang}/about`, label: t.nav.about },
    { href: `/${lang}/contact`, label: t.nav.contact },
  ];

  return (
    <header className="border-line bg-surface/90 sticky top-0 z-50 border-b backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-5 py-4 sm:px-8">
        <Wordmark lang={lang} />

        <nav className="hidden items-center gap-8 md:flex">
          {links.map((l) => {
            const active = pathname.startsWith(l.href);
            return (
              <Link
                key={l.href}
                href={l.href}
                className={`text-sm font-medium transition-colors ${
                  active
                    ? "text-accent underline decoration-2 underline-offset-[6px]"
                    : "text-fg hover:text-accent"
                }`}
              >
                {l.label}
              </Link>
            );
          })}
          <Link
            href={otherHref}
            hrefLang={other}
            className="text-fg-muted hover:text-fg border-line rounded-full border px-3 py-1 text-xs tracking-wide transition-colors"
          >
            {t.otherLangName}
          </Link>
          <Link
            href={`/${lang}/contact`}
            className="bg-inverse hover:bg-accent rounded-full px-6 py-2.5 text-sm font-bold text-on-inverse transition-colors"
          >
            {t.nav.enquire}
          </Link>
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-label="Menu"
          className="border-line text-fg flex h-10 w-10 items-center justify-center rounded-full border md:hidden"
        >
          <span className="relative block h-3 w-4">
            <span
              className={`bg-inverse absolute left-0 block h-px w-4 transition-transform ${
                open ? "top-1.5 rotate-45" : "top-0"
              }`}
            />
            <span
              className={`bg-inverse absolute left-0 block h-px w-4 transition-transform ${
                open ? "top-1.5 -rotate-45" : "top-3"
              }`}
            />
          </span>
        </button>
      </div>

      {open && (
        <nav className="border-line bg-surface border-t md:hidden">
          <div className="mx-auto flex max-w-6xl flex-col px-5 py-2 sm:px-8">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="border-line/60 text-fg-muted hover:text-fg border-b py-3.5 text-sm last:border-b-0"
              >
                {l.label}
              </Link>
            ))}
            <div className="flex items-center gap-3 py-4">
              <Link
                href={`/${lang}/contact`}
                className="bg-inverse flex-1 rounded-full px-5 py-3 text-center text-sm text-on-inverse"
              >
                {t.nav.enquire}
              </Link>
              <Link
                href={otherHref}
                hrefLang={other}
                className="border-line text-fg-muted rounded-full border px-4 py-3 text-sm"
              >
                {t.otherLangName}
              </Link>
            </div>
          </div>
        </nav>
      )}
    </header>
  );
}
