import Link from "next/link";
import { imageSrc, type Lang, type Product } from "@/lib/products";

export default function ProductCard({
  product,
  lang,
  priority = false,
}: {
  product: Product;
  lang: Lang;
  priority?: boolean;
}) {
  return (
    <Link href={`/${lang}/products/${product.slug}`} className="group block">
      {/* Bone panel: keeps the studio white off the colour bands. */}
      <div className="panel overflow-hidden p-3 transition-transform duration-300 group-hover:-translate-y-1 sm:p-4">
        <img
          src={imageSrc(product.slug, 1, "md")}
          srcSet={`${imageSrc(product.slug, 1, "sm")} 420w, ${imageSrc(product.slug, 1, "md")} 800w, ${imageSrc(product.slug, 1, "lg")} 1400w`}
          sizes="(max-width: 640px) 90vw, (max-width: 1024px) 45vw, 30vw"
          alt={product.name[lang]}
          loading={priority ? "eager" : "lazy"}
          fetchPriority={priority ? "high" : "auto"}
          width={800}
          height={800}
          className="aspect-square w-full object-cover"
        />
      </div>

      <div className="mt-4">
        <h3 className="font-display text-xl leading-tight font-semibold tracking-[-0.02em]">
          {product.name[lang]}
        </h3>
        <p className="text-fg-muted mt-2 text-sm leading-relaxed">
          {product.tagline[lang]}
        </p>

        {product.swatches.length > 1 && (
          <div className="mt-3 flex items-center gap-1.5">
            {product.swatches.map((s) => (
              <span
                key={s.hex + s.name.en}
                title={s.name[lang]}
                style={{ backgroundColor: s.hex }}
                className="block h-4 w-4 rounded-full shadow-[inset_0_0_0_1px_rgba(0,0,0,.18)]"
              />
            ))}
          </div>
        )}
      </div>
    </Link>
  );
}
