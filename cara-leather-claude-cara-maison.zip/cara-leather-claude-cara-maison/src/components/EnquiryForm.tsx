"use client";

import { useSearchParams } from "next/navigation";
import { useState } from "react";
import { getDict } from "@/i18n/dictionaries";
import { contact, whatsAppLink } from "@/lib/contact";
import {
  categories,
  getProduct,
  imageSrc,
  type Lang,
} from "@/lib/products";

/**
 * The site is a static export with no server of its own, so the enquiry is
 * posted to a form relay that emails it on to the office. Set
 * NEXT_PUBLIC_ENQUIRY_ENDPOINT to move to a different relay (or your own API)
 * without touching this component.
 */
const ENDPOINT =
  process.env.NEXT_PUBLIC_ENQUIRY_ENDPOINT ??
  `https://formsubmit.co/ajax/${contact.email}`;

const field =
  "border-line bg-surface-2 focus:border-accent w-full rounded-sm border px-4 py-3 text-sm outline-none transition-colors placeholder:text-fg-faint/70";
const labelCls = "text-fg-muted mb-1.5 block text-xs tracking-wide";

export default function EnquiryForm({ lang }: { lang: Lang }) {
  const t = getDict(lang);
  const search = useSearchParams();
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">(
    "idle",
  );

  const productSlug = search.get("product") ?? "";
  const product = productSlug ? getProduct(productSlug) : undefined;
  const presetInterest = product?.category ?? search.get("interest") ?? "";

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const values = Object.fromEntries(
      new FormData(form).entries(),
    ) as Record<string, string>;

    // Honeypot: a real person never fills a hidden field.
    if (values._honey) return;

    setState("sending");
    try {
      const res = await fetch(ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          ...values,
          _subject: product
            ? `Enquiry — ${product.name.en}`
            : "Enquiry — Cara Leather",
          _template: "table",
          _captcha: "false",
        }),
      });
      if (!res.ok) throw new Error(String(res.status));
      setState("sent");
      form.reset();
    } catch {
      setState("error");
    }
  }

  if (state === "sent") {
    return (
      <div
        role="status"
        className="border-line bg-surface-2 rounded-sm border p-8"
      >
        <p className="font-display text-2xl">{t.contact.sent}</p>
        <button
          type="button"
          onClick={() => setState("idle")}
          className="text-accent mt-5 text-sm font-bold underline underline-offset-4"
        >
          {t.contact.sendAnother}
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5">
      {product && (
        <>
          <input type="hidden" name="product" value={product.name.en} />
          <div className="border-line bg-surface-2 flex items-center gap-4 rounded-sm border p-4">
            <img
              src={imageSrc(product.slug, 1, "sm")}
              alt=""
              width={64}
              height={64}
              className="h-16 w-16 rounded-sm object-cover"
            />
            <div className="min-w-0">
              <p className="text-fg-faint text-xs">{t.contact.interest}</p>
              <p className="mt-0.5 text-sm font-medium">{product.name[lang]}</p>
            </div>
          </div>
        </>
      )}

      {/* Spam trap — hidden from people, irresistible to bots. */}
      <input
        type="text"
        name="_honey"
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
        className="absolute h-0 w-0 overflow-hidden opacity-0"
      />

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className={labelCls}>
            {t.contact.name} *
          </label>
          <input id="name" name="name" required className={field} />
        </div>
        <div>
          <label htmlFor="company" className={labelCls}>
            {t.contact.company}
          </label>
          <input id="company" name="company" className={field} />
        </div>
        <div>
          <label htmlFor="email" className={labelCls}>
            {t.contact.email} *
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            dir="ltr"
            className={field}
          />
        </div>
        <div>
          <label htmlFor="phone" className={labelCls}>
            {t.contact.phone}
          </label>
          <input
            id="phone"
            name="phone"
            type="tel"
            dir="ltr"
            className={field}
          />
        </div>
        <div>
          <label htmlFor="country" className={labelCls}>
            {t.contact.country}
          </label>
          <input id="country" name="country" className={field} />
        </div>
        <div>
          <label htmlFor="quantity" className={labelCls}>
            {t.contact.quantity}
          </label>
          <input
            id="quantity"
            name="quantity"
            inputMode="numeric"
            className={field}
          />
        </div>
      </div>

      <div>
        <label htmlFor="interest" className={labelCls}>
          {t.contact.interest}
        </label>
        <select
          id="interest"
          name="interest"
          defaultValue={presetInterest}
          className={field}
        >
          <option value="">{t.contact.selectPrompt}</option>
          {categories.map((c) => (
            <option key={c.slug} value={c.name.en}>
              {c.name[lang]}
            </option>
          ))}
          <option value="General enquiry">{t.contact.generalEnquiry}</option>
        </select>
      </div>

      <div>
        <label htmlFor="message" className={labelCls}>
          {t.contact.message} *
        </label>
        <textarea
          id="message"
          name="message"
          required
          rows={6}
          placeholder={t.contact.messagePlaceholder}
          className={`${field} resize-y`}
        />
      </div>

      <button
        type="submit"
        disabled={state === "sending"}
        className="bg-inverse hover:bg-accent rounded-full px-9 py-3.5 text-sm font-bold text-on-inverse transition-colors disabled:opacity-60"
      >
        {state === "sending" ? t.contact.sending : t.contact.submit}
      </button>

      {state === "error" && (
        <div role="alert" className="border-accent border-s-2 ps-4 text-sm">
          <p>{t.contact.error}</p>
          <a
            href={whatsAppLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="text-accent mt-2 inline-block font-bold underline underline-offset-4"
          >
            {t.contact.whatsappCta}
          </a>
        </div>
      )}
    </form>
  );
}
