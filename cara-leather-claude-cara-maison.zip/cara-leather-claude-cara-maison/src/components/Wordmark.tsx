import Link from "next/link";
import type { Lang } from "@/lib/products";
import { getDict } from "@/i18n/dictionaries";

/**
 * The brand mark, supplied as artwork. Two colourways: the dark mark for the
 * bone header, the light one for the ink footer.
 */
export default function Wordmark({
  lang,
  tone = "default",
}: {
  lang: Lang;
  tone?: "default" | "inverse";
}) {
  const t = getDict(lang);
  const src =
    tone === "inverse"
      ? "/brand/cara-wordmark-light.png"
      : "/brand/cara-wordmark.png";

  return (
    <Link href={`/${lang}`} className="block shrink-0">
      <img
        src={src}
        alt={t.brand}
        width={1200}
        height={536}
        className="h-10 w-auto sm:h-11"
      />
    </Link>
  );
}
