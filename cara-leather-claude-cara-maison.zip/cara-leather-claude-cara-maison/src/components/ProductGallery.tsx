"use client";

import { useState } from "react";
import { imageSrc, type Lang, type Product } from "@/lib/products";

export default function ProductGallery({
  product,
  lang,
}: {
  product: Product;
  lang: Lang;
}) {
  const [active, setActive] = useState(1);
  const indexes = Array.from({ length: product.images }, (_, i) => i + 1);

  return (
    <div>
      <div className="panel relative aspect-square overflow-hidden p-4 sm:p-6">
        <img
          key={active}
          src={imageSrc(product.slug, active, "lg")}
          srcSet={`${imageSrc(product.slug, active, "md")} 800w, ${imageSrc(product.slug, active, "lg")} 1400w`}
          sizes="(max-width: 1024px) 92vw, 50vw"
          alt={`${product.name[lang]} — ${active}`}
          width={1400}
          height={1400}
          fetchPriority="high"
          className="h-full w-full object-cover"
        />
      </div>

      {product.images > 1 && (
        <div className="mt-3 flex gap-3">
          {indexes.map((i) => (
            <button
              key={i}
              type="button"
              onClick={() => setActive(i)}
              aria-label={`${product.name[lang]} — ${i}`}
              aria-current={active === i}
              className={`panel relative h-20 w-20 overflow-hidden transition-all ${
                active === i
                  ? "ring-accent ring-2 ring-offset-2 ring-offset-[var(--color-surface)]"
                  : "opacity-60 hover:opacity-100"
              }`}
            >
              <img
                src={imageSrc(product.slug, i, "sm")}
                alt=""
                loading="lazy"
                width={160}
                height={160}
                className="h-full w-full object-cover"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
