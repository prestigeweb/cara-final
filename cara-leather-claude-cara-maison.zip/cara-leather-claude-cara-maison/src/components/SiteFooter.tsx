import Link from "next/link";
import Wordmark from "./Wordmark";
import { getDict } from "@/i18n/dictionaries";
import { categories, type Lang } from "@/lib/products";
import { contact, whatsAppLink } from "@/lib/contact";

export default function SiteFooter({ lang }: { lang: Lang }) {
  const t = getDict(lang);

  return (
    <footer className="bg-inverse text-on-inverse mt-24">
      <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 md:grid-cols-[1.5fr_1fr_1fr_1.2fr]">
          <div>
            <Wordmark lang={lang} tone="inverse" />
            <p className="text-on-inverse/55 mt-5 max-w-xs text-sm leading-relaxed">
              {t.footer.tagline}
            </p>
          </div>

          <div>
            <h3 className="text-on-inverse/50 text-[0.6875rem] font-bold tracking-[0.2em] uppercase">
              {t.footer.collections}
            </h3>
            <ul className="mt-4 space-y-2.5">
              {categories.map((c) => (
                <li key={c.slug}>
                  <Link
                    href={`/${lang}/collections/${c.slug}`}
                    className="text-on-inverse/70 hover:text-on-inverse text-sm transition-colors"
                  >
                    {c.name[lang]}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-on-inverse/50 text-[0.6875rem] font-bold tracking-[0.2em] uppercase">
              {t.footer.company}
            </h3>
            <ul className="mt-4 space-y-2.5">
              <li>
                <Link
                  href={`/${lang}/about`}
                  className="text-on-inverse/70 hover:text-on-inverse text-sm transition-colors"
                >
                  {t.nav.about}
                </Link>
              </li>
              <li>
                <Link
                  href={`/${lang}/contact`}
                  className="text-on-inverse/70 hover:text-on-inverse text-sm transition-colors"
                >
                  {t.nav.contact}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-on-inverse/50 text-[0.6875rem] font-bold tracking-[0.2em] uppercase">
              {t.footer.getInTouch}
            </h3>
            <ul className="text-on-inverse/70 mt-4 space-y-2.5 text-sm">
              <li>
                <a
                  href={`mailto:${contact.email}`}
                  className="hover:text-on-inverse transition-colors"
                >
                  {contact.email}
                </a>
              </li>
              <li>
                <a
                  href={whatsAppLink(t.whatsappGreeting)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-on-inverse transition-colors"
                >
                  {t.contactInfo.whatsappLabel}{" "}
                  <span dir="ltr">{contact.whatsappDisplay}</span>
                </a>
              </li>
              <li>{t.contactInfo.address}</li>
              <li>{t.contactInfo.hours}</li>
            </ul>
          </div>
        </div>

        <div className="border-on-inverse/10 mt-14 flex flex-col gap-3 border-t pt-7 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-on-inverse/40 text-xs">
            © {new Date().getFullYear()} {t.brand}. {t.footer.rights}
          </p>
        </div>
      </div>
    </footer>
  );
}
