import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import ProductCard from "@/components/ProductCard";
import ProductGallery from "@/components/ProductGallery";
import { getDict, languages, toLang } from "@/i18n/dictionaries";
import {
  getCategory,
  getProduct,
  products,
  productsIn,
  type Lang,
} from "@/lib/products";

type Params = { lang: string; slug: string };

export function generateStaticParams() {
  return languages.flatMap((lang) =>
    products.map((p) => ({ lang, slug: p.slug })),
  );
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { lang: rawLang, slug } = await params;
  const lang = toLang(rawLang);
  const p = getProduct(slug);
  if (!p) return {};
  return { title: p.name[lang], description: p.tagline[lang] };
}

export default async function ProductPage({
  params,
}: {
  params: Promise<Params>;
}) {
  const { lang: rawLang, slug } = await params;
  const lang = toLang(rawLang);
  const product = getProduct(slug);
  if (!product) notFound();

  const t = getDict(lang);
  const category = getCategory(product.category)!;
  const related = productsIn(product.category)
    .filter((p) => p.slug !== product.slug)
    .slice(0, 3);

  return (
    <div className="mx-auto max-w-6xl px-5 py-12 sm:px-8 lg:py-16">
      <Link
        href={`/${lang}/collections/${category.slug}`}
        className="text-fg-faint hover:text-fg text-sm transition-colors"
      >
        <span className="rtl-flip inline-block">←</span> {t.product.backTo}{" "}
        {category.name[lang]}
      </Link>

      <div className="mt-8 grid gap-10 lg:grid-cols-2 lg:gap-16">
        <ProductGallery product={product} lang={lang} />

        <div className="lg:pt-2">
          <p className="text-accent-deep text-xs tracking-[0.22em] uppercase">
            {category.name[lang]}
          </p>
          <h1 className="font-display mt-4 text-4xl leading-tight sm:text-5xl">
            {product.name[lang]}
          </h1>
          <p className="text-fg-muted mt-5 text-lg leading-relaxed">
            {product.description[lang]}
          </p>

          {/* ------------------------------------------------- colourways */}
          <section className="border-line mt-9 border-t pt-7">
            <h2 className="text-xs tracking-[0.2em] uppercase">
              {t.product.colours}
            </h2>
            <ul className="mt-4 flex flex-wrap gap-x-6 gap-y-3">
              {product.swatches.map((s) => (
                <li
                  key={s.hex + s.name.en}
                  className="flex items-center gap-2.5"
                >
                  <span
                    style={{ backgroundColor: s.hex }}
                    className="ring-line block h-5 w-5 rounded-full ring-1"
                  />
                  <span className="text-fg-muted text-sm">{s.name[lang]}</span>
                </li>
              ))}
            </ul>
            <p className="text-fg-faint mt-4 text-xs leading-relaxed">
              {t.product.colourNote}
            </p>
          </section>

          {/* ------------------------------------------------------ specs */}
          <section className="border-line mt-8 border-t pt-7">
            <h2 className="text-xs tracking-[0.2em] uppercase">
              {t.product.specs}
            </h2>
            <dl className="mt-4 space-y-3">
              {product.specs.map((s) => (
                <div
                  key={s.label.en}
                  className="border-line/60 flex flex-col gap-1 border-b pb-3 last:border-b-0 sm:flex-row sm:gap-6"
                >
                  <dt className="text-fg-faint text-sm sm:w-40 sm:shrink-0">
                    {s.label[lang]}
                  </dt>
                  <dd className="text-sm">{s.value[lang]}</dd>
                </div>
              ))}
            </dl>
          </section>

          {/* ----------------------------------------------------- enquiry */}
          <div className="bg-surface-2/60 mt-9 rounded-sm p-6">
            <Link
              href={`/${lang}/contact?product=${product.slug}&interest=${product.category}`}
              className="bg-inverse hover:bg-accent-deep inline-block rounded-full px-8 py-3.5 text-sm font-bold text-on-inverse transition-colors"
            >
              {t.product.enquire}
            </Link>
            <p className="text-fg-muted mt-3 text-sm leading-relaxed">
              {t.product.enquireNote}
            </p>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="border-line mt-24 border-t pt-12">
          <h2 className="font-display text-3xl">{t.product.related}</h2>
          <div className="mt-8 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((p) => (
              <ProductCard key={p.slug} product={p} lang={lang} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
