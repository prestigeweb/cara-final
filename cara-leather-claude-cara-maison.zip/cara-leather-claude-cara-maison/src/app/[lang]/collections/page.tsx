import type { Metadata } from "next";
import Link from "next/link";
import { getDict, languages, toLang } from "@/i18n/dictionaries";
import {
  categories,
  getProduct,
  imageSrc,
  productsIn,
  type Lang,
} from "@/lib/products";

export function generateStaticParams() {
  return languages.map((lang) => ({ lang }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ lang: string }>;
}): Promise<Metadata> {
  const { lang: rawLang } = await params;
  const lang = toLang(rawLang);
  const t = getDict(lang);
  return { title: t.collections.title, description: t.collections.lede };
}

export default async function CollectionsPage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang: rawLang } = await params;
  const lang = toLang(rawLang);
  const t = getDict(lang);

  return (
    <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-20">
      <header className="max-w-2xl">
        <h1 className="font-display text-5xl sm:text-6xl">
          {t.collections.title}
        </h1>
        <p className="text-fg-muted mt-5 text-lg leading-relaxed">
          {t.collections.lede}
        </p>
      </header>

      <div className="mt-14 space-y-16">
        {categories.map((c, i) => {
          const items = productsIn(c.slug);
          const cover = getProduct(c.cover)!;
          return (
            <section
              key={c.slug}
              className="border-line grid gap-8 border-t pt-10 lg:grid-cols-[1fr_1.4fr] lg:gap-12"
            >
              <div>
                <Link
                  href={`/${lang}/collections/${c.slug}`}
                  className="group block"
                >
                  <div className="bg-surface-2 relative aspect-[4/3] overflow-hidden rounded-sm">
                    <img
                      src={imageSrc(cover.slug, 1, "md")}
                      srcSet={`${imageSrc(cover.slug, 1, "sm")} 420w, ${imageSrc(cover.slug, 1, "md")} 800w`}
                      sizes="(max-width: 1024px) 90vw, 35vw"
                      alt={c.name[lang]}
                      loading={i === 0 ? "eager" : "lazy"}
                      width={800}
                      height={600}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                    />
                  </div>
                </Link>
                <h2 className="font-display mt-5 text-3xl">
                  <Link
                    href={`/${lang}/collections/${c.slug}`}
                    className="hover:text-accent-deep transition-colors"
                  >
                    {c.name[lang]}
                  </Link>
                </h2>
                <p className="text-fg-muted mt-3 leading-relaxed">
                  {c.blurb[lang]}
                </p>
                <Link
                  href={`/${lang}/collections/${c.slug}`}
                  className="text-accent-deep mt-5 inline-block text-sm underline underline-offset-4"
                >
                  {t.collections.viewAll} →
                </Link>
              </div>

              <ul className="grid min-w-0 gap-x-6 gap-y-4 sm:grid-cols-2">
                {items.map((p) => (
                  <li key={p.slug} className="min-w-0">
                    <Link
                      href={`/${lang}/products/${p.slug}`}
                      className="group border-line/70 flex items-center gap-4 border-b py-3"
                    >
                      <img
                        src={imageSrc(p.slug, 1, "sm")}
                        alt=""
                        loading="lazy"
                        width={72}
                        height={72}
                        className="panel h-16 w-16 shrink-0 object-cover p-1"
                      />
                      <span className="min-w-0">
                        <span className="group-hover:text-accent-deep block text-sm font-medium transition-colors">
                          {p.name[lang]}
                        </span>
                        <span className="text-fg-faint mt-0.5 block text-xs">
                          {p.tagline[lang]}
                        </span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          );
        })}
      </div>
    </div>
  );
}
