import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import ProductCard from "@/components/ProductCard";
import { getDict, languages, toLang } from "@/i18n/dictionaries";
import {
  categories,
  getCategory,
  productsIn,
  type CategorySlug,
  type Lang,
} from "@/lib/products";

type Params = { lang: string; category: string };

export function generateStaticParams() {
  return languages.flatMap((lang) =>
    categories.map((c) => ({ lang, category: c.slug })),
  );
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { lang: rawLang, category } = await params;
  const lang = toLang(rawLang);
  const c = getCategory(category);
  if (!c) return {};
  return { title: c.name[lang], description: c.blurb[lang] };
}

export default async function CategoryPage({
  params,
}: {
  params: Promise<Params>;
}) {
  const { lang: rawLang, category } = await params;
  const lang = toLang(rawLang);
  const c = getCategory(category);
  if (!c) notFound();

  const t = getDict(lang);
  const items = productsIn(c.slug);

  return (
    <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-20">
      <Link
        href={`/${lang}/collections`}
        className="text-fg-faint hover:text-fg text-sm transition-colors"
      >
        <span className="rtl-flip inline-block">←</span> {t.collections.title}
      </Link>

      <header className="mt-6 max-w-2xl">
        <h1 className="font-display text-5xl sm:text-6xl">{c.name[lang]}</h1>
        <p className="text-fg-muted mt-5 text-lg leading-relaxed">
          {c.blurb[lang]}
        </p>
        <p className="text-fg-faint mt-3 text-sm">
          {t.collections.itemCount(items.length)}
        </p>
      </header>

      <div className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p, i) => (
          <ProductCard key={p.slug} product={p} lang={lang} priority={i < 3} />
        ))}
      </div>

      <div className="border-line mt-20 border-t pt-10">
        <h2 className="font-display text-2xl">{t.home.ctaTitle}</h2>
        <p className="text-fg-muted mt-2 max-w-xl leading-relaxed">
          {t.home.ctaBody}
        </p>
        <Link
          href={`/${lang}/contact?interest=${c.slug}`}
          className="bg-inverse hover:bg-accent-deep mt-6 inline-block rounded-full px-8 py-3.5 text-sm font-bold text-on-inverse transition-colors"
        >
          {t.nav.enquire}
        </Link>
      </div>
    </div>
  );
}
