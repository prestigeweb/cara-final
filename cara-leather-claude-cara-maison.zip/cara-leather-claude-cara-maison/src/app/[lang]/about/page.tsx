import type { Metadata } from "next";
import Link from "next/link";
import { getDict, languages, toLang } from "@/i18n/dictionaries";
import { imageSrc, type Lang } from "@/lib/products";

export function generateStaticParams() {
  return languages.map((lang) => ({ lang }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ lang: string }>;
}): Promise<Metadata> {
  const { lang: rawLang } = await params;
  const lang = toLang(rawLang);
  const t = getDict(lang);
  return { title: t.about.title, description: t.about.lede };
}

export default async function AboutPage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang: rawLang } = await params;
  const lang = toLang(rawLang);
  const t = getDict(lang);

  return (
    <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-20">
      <header className="max-w-3xl">
        <h1 className="font-display text-5xl sm:text-6xl">{t.about.title}</h1>
        <p className="text-fg-muted mt-5 text-xl leading-relaxed">
          {t.about.lede}
        </p>
      </header>

      <div className="mt-14 grid gap-12 lg:grid-cols-[1.2fr_1fr] lg:gap-16">
        <div className="space-y-6">
          {t.about.body.map((para) => (
            <p key={para.slice(0, 24)} className="leading-relaxed">
              {para}
            </p>
          ))}
        </div>

        <div className="bg-surface-2 relative aspect-[4/5] overflow-hidden rounded-sm">
          <img
            src={imageSrc("strap-close-keepsake-box", 1, "md")}
            srcSet={`${imageSrc("strap-close-keepsake-box", 1, "sm")} 420w, ${imageSrc("strap-close-keepsake-box", 1, "md")} 800w`}
            sizes="(max-width: 1024px) 90vw, 40vw"
            alt=""
            width={800}
            height={1000}
            className="h-full w-full object-cover"
          />
        </div>
      </div>

      <section className="border-line mt-20 border-t pt-12">
        <h2 className="font-display text-4xl">{t.about.valuesTitle}</h2>
        <div className="mt-10 grid gap-10 sm:grid-cols-3">
          {t.about.values.map((v) => (
            <div key={v.title}>
              <h3 className="text-base font-medium">{v.title}</h3>
              <p className="text-fg-muted mt-2 text-sm leading-relaxed">
                {v.body}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-line mt-20 border-t pt-12">
        <h2 className="font-display text-3xl">{t.home.ctaTitle}</h2>
        <p className="text-fg-muted mt-2 max-w-xl leading-relaxed">
          {t.home.ctaBody}
        </p>
        <Link
          href={`/${lang}/contact`}
          className="bg-inverse hover:bg-accent-deep mt-6 inline-block rounded-full px-8 py-3.5 text-sm font-bold text-on-inverse transition-colors"
        >
          {t.nav.enquire}
        </Link>
      </section>
    </div>
  );
}
