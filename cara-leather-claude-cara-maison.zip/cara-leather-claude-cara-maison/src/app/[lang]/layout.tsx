import type { Metadata } from "next";
import { Fraunces, Noto_Sans_Arabic, Schibsted_Grotesk } from "next/font/google";
import { notFound } from "next/navigation";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import WhatsAppButton from "@/components/WhatsAppButton";
import { dir, getDict, isLang, languages, toLang } from "@/i18n/dictionaries";
import type { Lang } from "@/lib/products";

const display = Fraunces({
  subsets: ["latin"],
  weight: ["400", "600", "900"],
  variable: "--font-display",
  display: "swap",
});

const body = Schibsted_Grotesk({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-body",
  display: "swap",
});

const arabic = Noto_Sans_Arabic({
  subsets: ["arabic"],
  variable: "--font-body",
  display: "swap",
});

export function generateStaticParams() {
  return languages.map((lang) => ({ lang }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ lang: string }>;
}): Promise<Metadata> {
  const { lang: rawLang } = await params;
  const lang = toLang(rawLang);
  const t = getDict(lang);
  return {
    title: {
      default:
        lang === "ar"
          ? "كارا — مصنّع منتجات جلدية"
          : "Cara — Leather Goods Manufacturer",
      template: lang === "ar" ? `%s — كارا` : "%s — Cara Leather",
    },
    description: t.footer.tagline,
    alternates: {
      languages: { en: "/en", ar: "/ar" },
    },
  };
}

export default async function LangLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ lang: string }>;
}) {
  const { lang: rawLang } = await params;
  if (!isLang(rawLang)) notFound();
  const lang = toLang(rawLang);

  const fontVars =
    lang === "ar"
      ? `${arabic.variable} ${display.variable}`
      : `${body.variable} ${display.variable}`;

  return (
    <html lang={lang} dir={dir(lang)} className={fontVars}>
      <body className="flex min-h-screen flex-col">
        <SiteHeader lang={lang} />
        <main className="flex-1">{children}</main>
        <SiteFooter lang={lang} />
        <WhatsAppButton lang={lang} />
      </body>
    </html>
  );
}
