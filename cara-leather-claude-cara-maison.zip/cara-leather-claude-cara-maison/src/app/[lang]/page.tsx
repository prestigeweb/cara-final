import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { getDict, languages, toLang } from "@/i18n/dictionaries";
import {
  categories,
  getProduct,
  imageSrc,
  products,
  productsIn,
  type Lang,
} from "@/lib/products";

export function generateStaticParams() {
  return languages.map((lang) => ({ lang }));
}

/** Each range takes a band in a colour Cara actually stocks. */
const BANDS = ["band-oxblood", "band-navy", "band-forest", ""] as const;

export default async function HomePage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang: rawLang } = await params;
  const lang: Lang = toLang(rawLang);
  const t = getDict(lang);
  const hero = getProduct("crossbody-messenger-bag")!;
  // The whole catalogue, in range order, rather than a selection.
  const catalogue = categories.flatMap((c) => productsIn(c.slug));

  /* Every stock colour on the shelf, de-duplicated across the catalogue. */
  const swatches = Array.from(
    new Map(
      products.flatMap((p) => p.swatches).map((s) => [s.name.en, s]),
    ).values(),
  );

  return (
    <>
      {/* ------------------------------------------- hero band, forest green */}
      <section className="band band-forest pt-14 pb-28 sm:pt-20 lg:pb-36">
        <div className="mx-auto max-w-6xl px-5 sm:px-8">
          <p className="text-[0.6875rem] font-bold tracking-[0.26em] text-[#8fc0a5] uppercase">
            {t.home.eyebrow}
          </p>
          <h1 className="font-display mt-5 max-w-[13ch] text-[2.8rem] leading-[0.94] font-black tracking-[-0.038em] sm:text-7xl lg:text-[6.5rem]">
            {t.home.title}
          </h1>
          <p className="text-fg-muted mt-7 max-w-[44ch] text-lg leading-relaxed">
            {t.home.lede}
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link
              href={`/${lang}/collections`}
              className="bg-on-inverse rounded-full px-8 py-3.5 text-sm font-bold text-[var(--color-forest)] transition-transform hover:-translate-y-0.5"
            >
              {t.home.ctaPrimary}
            </Link>
            <Link
              href={`/${lang}/contact`}
              className="hover:bg-on-inverse rounded-full border-2 border-current px-8 py-3.5 text-sm font-bold transition-colors hover:text-[var(--color-forest)]"
            >
              {t.home.ctaSecondary}
            </Link>
          </div>
        </div>
      </section>

      {/* The shelf panel rides across the seam of the band above it. */}
      <div className="mx-auto -mt-20 max-w-6xl px-5 sm:px-8 lg:-mt-28">
        <div className="panel p-4 sm:p-6">
          <img
            src={imageSrc(hero.slug, 1, "lg")}
            srcSet={`${imageSrc(hero.slug, 1, "md")} 800w, ${imageSrc(hero.slug, 1, "lg")} 1400w`}
            sizes="(max-width: 1024px) 92vw, 72rem"
            alt={hero.name[lang]}
            width={1400}
            height={790}
            fetchPriority="high"
            className="aspect-[16/9] w-full object-cover"
            style={{ objectPosition: "50% 62%" }}
          />
        </div>
      </div>

      {/* --------------------------------------------------- the leather shelf */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <p className="text-fg-faint text-[0.6875rem] font-bold tracking-[0.26em] uppercase">
          {t.maison.stockLeathers}
        </p>
        <h2 className="font-display mt-3 max-w-[22ch] text-2xl leading-tight font-semibold tracking-[-0.02em] sm:text-3xl">
          {t.maison.stockLine}
        </h2>
        <ul className="mt-7 flex flex-wrap gap-x-7 gap-y-4">
          {swatches.map((s) => (
            <li key={s.name.en} className="text-fg-muted flex items-center gap-2.5 text-sm">
              <span
                style={{ backgroundColor: s.hex }}
                className="block h-6 w-6 rounded-full shadow-[inset_0_0_0_1px_rgba(0,0,0,.18)]"
              />
              {s.name[lang]}
            </li>
          ))}
        </ul>
      </section>

      {/* ------------------------------------------------ one band per range */}
      {categories.map((c, i) => {
        const cover = getProduct(c.cover)!;
        const band = BANDS[i];
        const count = productsIn(c.slug).length;
        const onBand = band !== "";
        return (
          <section
            key={c.slug}
            className={onBand ? `band ${band} py-14 lg:py-20` : "py-14 lg:py-20"}
          >
            <div
              className={`mx-auto grid max-w-6xl items-center gap-8 px-5 sm:px-8 lg:grid-cols-[1fr_1.1fr] lg:gap-14 ${
                i % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""
              }`}
            >
              <div>
                <p className="text-fg-faint text-[0.6875rem] font-bold tracking-[0.26em] uppercase">
                  {t.maison.range} {String(i + 1).padStart(2, "0")}
                </p>
                <h2 className="font-display mt-4 max-w-[14ch] text-[2rem] leading-[1.03] font-semibold tracking-[-0.028em] sm:text-5xl">
                  {c.name[lang]}
                </h2>
                <p className="text-fg-muted mt-5 max-w-[42ch] leading-relaxed">
                  {c.blurb[lang]}
                </p>
                <Link
                  href={`/${lang}/collections/${c.slug}`}
                  className="mt-6 inline-block border-b-2 border-current pb-1 text-sm font-bold"
                >
                  {t.collections.itemCount(count)}
                </Link>
              </div>
              <div className="panel p-4 sm:p-5">
                <img
                  src={imageSrc(cover.slug, 1, "md")}
                  srcSet={`${imageSrc(cover.slug, 1, "sm")} 420w, ${imageSrc(cover.slug, 1, "md")} 800w`}
                  sizes="(max-width: 1024px) 90vw, 45vw"
                  alt={c.name[lang]}
                  loading="lazy"
                  width={800}
                  height={600}
                  className="aspect-[4/3] w-full object-cover"
                />
              </div>
            </div>
          </section>
        );
      })}

      {/* ------------------------------------------------------ the figures */}
      <section className="mx-auto max-w-6xl px-5 sm:px-8">
        <dl className="border-fg grid gap-8 border-t-2 py-12 sm:grid-cols-2 lg:grid-cols-4">
          {t.home.stats.map((s) => (
            <div key={s.label}>
              <dt className="font-display text-4xl font-black tracking-[-0.03em] tabular-nums sm:text-5xl">
                {s.value}
              </dt>
              <dd className="text-fg-muted mt-2 max-w-[20ch] text-sm leading-snug">
                {s.label}
              </dd>
            </div>
          ))}
        </dl>
      </section>

      {/* -------------------------------------------------- selected pieces */}
      <section className="mx-auto max-w-6xl px-5 pb-16 sm:px-8">
        <h2 className="font-display text-3xl font-semibold tracking-[-0.025em] sm:text-4xl">
          {t.home.featuredTitle}
        </h2>
        <p className="text-fg-muted mt-3 max-w-[54ch] leading-relaxed">
          {t.home.featuredLede}
        </p>
        <div className="mt-10 grid gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {catalogue.map((p) => (
            <ProductCard key={p.slug} product={p} lang={lang} />
          ))}
        </div>
      </section>

      {/* -------------------------------------------------------------- cta */}
      <section className="bg-inverse text-on-inverse">
        <div className="mx-auto flex max-w-6xl flex-wrap items-end justify-between gap-7 px-5 py-16 sm:px-8 lg:py-20">
          <div>
            <h2 className="font-display max-w-[16ch] text-[2rem] leading-none font-black tracking-[-0.035em] sm:text-5xl">
              {t.home.ctaTitle}
            </h2>
            <p className="mt-5 max-w-[40ch] leading-relaxed text-[#a8a29a]">
              {t.home.ctaBody}
            </p>
          </div>
          <Link
            href={`/${lang}/contact`}
            className="bg-on-inverse text-inverse rounded-full px-9 py-4 text-sm font-bold whitespace-nowrap transition-transform hover:-translate-y-0.5"
          >
            {t.nav.enquire}
          </Link>
        </div>
      </section>
    </>
  );
}
