import type { Metadata } from "next";
import { Suspense } from "react";
import EnquiryForm from "@/components/EnquiryForm";
import { getDict, languages, toLang } from "@/i18n/dictionaries";
import type { Lang } from "@/lib/products";
import { contact, whatsAppLink } from "@/lib/contact";

export function generateStaticParams() {
  return languages.map((lang) => ({ lang }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ lang: string }>;
}): Promise<Metadata> {
  const { lang: rawLang } = await params;
  const lang = toLang(rawLang);
  const t = getDict(lang);
  return { title: t.contact.title, description: t.contact.lede };
}

export default async function ContactPage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang: rawLang } = await params;
  const lang = toLang(rawLang);
  const t = getDict(lang);

  return (
    <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-20">
      <header className="max-w-2xl">
        <h1 className="font-display text-5xl sm:text-6xl">{t.contact.title}</h1>
        <p className="text-fg-muted mt-5 text-lg leading-relaxed">
          {t.contact.lede}
        </p>
      </header>

      <div className="mt-14 grid gap-12 lg:grid-cols-[1.4fr_1fr] lg:gap-20">
        <Suspense fallback={<div className="h-96" />}>
          <EnquiryForm lang={lang} />
        </Suspense>

        <aside className="border-line lg:border-s lg:ps-12">
          <h2 className="text-xs tracking-[0.2em] uppercase">
            {t.contact.directTitle}
          </h2>
          <dl className="mt-6 space-y-5 text-sm">
            <div>
              <dt className="text-fg-faint text-xs">{t.contact.email}</dt>
              <dd className="mt-1">
                <a
                  href={`mailto:${contact.email}`}
                  dir="ltr"
                  className="hover:text-accent underline underline-offset-4 transition-colors"
                >
                  {contact.email}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-fg-faint text-xs">
                {t.contactInfo.whatsappLabel}
              </dt>
              <dd className="mt-1">
                <a
                  href={whatsAppLink(t.whatsappGreeting)}
                  target="_blank"
                  rel="noopener noreferrer"
                  dir="ltr"
                  className="hover:text-accent inline-block underline underline-offset-4 transition-colors"
                >
                  {contact.whatsappDisplay}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-fg-faint text-xs">
                {t.contactInfo.addressLabel}
              </dt>
              <dd className="mt-1">{t.contactInfo.address}</dd>
            </div>
            <div>
              <dt className="text-fg-faint text-xs">{t.contact.hours}</dt>
              <dd className="mt-1">{t.contactInfo.hours}</dd>
            </div>
          </dl>
        </aside>
      </div>
    </div>
  );
}
