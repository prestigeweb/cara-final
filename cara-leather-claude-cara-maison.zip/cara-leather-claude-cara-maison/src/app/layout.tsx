import type { Metadata } from "next";
import "./globals.css";

/**
 * No title here. The [lang] layout owns the title and its template, and Next
 * wraps a child layout's `default` in the parent's template — declaring one at
 * both levels appended the suffix twice on the home page, and put the English
 * suffix on the Arabic page.
 */
export const metadata: Metadata = {
  description:
    "Cara manufactures jewellery packaging, corporate gifts, bags and small leather goods for brands that put their own mark on the lid.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
