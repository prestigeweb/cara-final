import Link from "next/link";

export default function NotFound() {
  return (
    <html lang="en">
      <body className="flex min-h-screen items-center justify-center bg-[#f6f3ee] px-6 text-center text-[#1c1917]">
        <div>
          <p className="text-xs tracking-[0.25em] text-[#85552c] uppercase">
            404
          </p>
          <h1 className="mt-4 font-serif text-4xl">Page not found</h1>
          <p className="mt-3 text-sm text-[#57504a]">
            That page is not part of the catalogue.
          </p>
          <Link
            href="/en"
            className="mt-8 inline-block rounded-full bg-[#1c1917] px-7 py-3.5 text-sm text-on-inverse"
          >
            Back to Cara
          </Link>
        </div>
      </body>
    </html>
  );
}
