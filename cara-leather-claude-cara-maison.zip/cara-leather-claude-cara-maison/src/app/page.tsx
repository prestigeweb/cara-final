import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Cara — Leather Goods Manufacturer",
  robots: { index: false, follow: true },
};

/**
 * Static export has no server, so the root cannot issue a 3xx. This page sends
 * the visitor to their own language when the browser asks for Arabic, and to
 * English otherwise, with a meta refresh as the no-JavaScript fallback.
 */
const BASE = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

const REDIRECT = `(function(){try{var l=(navigator.languages&&navigator.languages[0])||navigator.language||"en";location.replace(l.toLowerCase().indexOf("ar")===0?"${BASE}/ar/":"${BASE}/en/");}catch(e){location.replace("${BASE}/en/");}})();`;

export default function RootPage() {
  return (
    <html lang="en">
      <head>
        <meta httpEquiv="refresh" content={`0; url=${BASE}/en/`} />
        <script dangerouslySetInnerHTML={{ __html: REDIRECT }} />
      </head>
      <body style={{ background: "#f6f3ee" }}>
        <noscript>
          <p style={{ fontFamily: "system-ui, sans-serif", padding: "2rem" }}>
            <a href={`${BASE}/en/`}>English</a> · <a href={`${BASE}/ar/`}>العربية</a>
          </p>
        </noscript>
      </body>
    </html>
  );
}
