import type { Lang } from "@/lib/products";

export const languages: Lang[] = ["en", "ar"];

export const dir = (lang: Lang) => (lang === "ar" ? "rtl" : "ltr");

export const dictionaries = {
  en: {
    langName: "English",
    otherLangName: "العربية",
    brand: "Cara",
    whatsappGreeting: "Hello Cara — I would like a quote for",
    brandLine: "Leather Goods",
    maison: {
      stockLeathers: "Stock leathers",
      stockLine:
        "Twenty colours on the shelf. Anything else matched to a swatch.",
      range: "Range",
    },
    nav: {
      collections: "Collections",
      capabilities: "Capabilities",
      about: "About",
      contact: "Contact",
      enquire: "Request a quote",
    },
    home: {
      eyebrow: "Leather goods manufacturer",
      title: "Leather that carries someone else's name.",
      lede: "Cara makes jewellery packaging, corporate gifts, bags and small leather goods for brands that put their own mark on the lid. Cut, stitched, lined and finished to your specification.",
      ctaPrimary: "Browse the catalogue",
      ctaSecondary: "Start an enquiry",
      statsTitle: "Built around your order",
      stats: [
        { value: "250", label: "Minimum order, most lines" },
        { value: "4–6", label: "Weeks, sampling to delivery" },
        { value: "20+", label: "Stock leather colourways" },
        { value: "100%", label: "Hand-finished edges" },
      ],
      collectionsTitle: "Collections",
      collectionsLede:
        "Four ranges, all made in the same workshop, all open to customisation.",
      featuredTitle: "Everything we make",
      featuredLede:
        "The full catalogue. Every line below can be recoloured, resized, relined and rebranded.",
      processTitle: "How an order runs",
      processLede:
        "From the first drawing to the pallet. You have one contact for all of it.",
      process: [
        {
          title: "Brief and drawing",
          body: "Send us a piece, a sketch or a competitor's box. We come back with a drawing, a leather shortlist and a unit price against your quantity.",
        },
        {
          title: "Sample",
          body: "We cut one. You get the real thing in your hands — leather, lining, stitch colour, branding — and you mark it up until it is right.",
        },
        {
          title: "Production",
          body: "Approved sample becomes the standard. Every unit is checked against it before it is wrapped.",
        },
        {
          title: "Delivery",
          body: "Cartoned, labelled to your spec and shipped on your incoterms. Repeat orders run from the same approved sample.",
        },
      ],
      customTitle: "Customisation",
      customLede: "The parts of a piece you can change.",
      custom: [
        {
          title: "Leather and colour",
          body: "Pebble grain, smooth calf or waxed suede, in any of our stock colours or matched to a swatch you send.",
        },
        {
          title: "Lining",
          body: "Suede, microfibre or fabric, in a contrasting or matching tone. Inserts cut to the piece the box will hold.",
        },
        {
          title: "Branding",
          body: "Blind deboss, hot foil in gold or silver, screen print, or a machined metal plate set into the lid.",
        },
        {
          title: "Sizing",
          body: "Any dimension on any box can move. Tell us what goes inside and we will build the shell around it.",
        },
      ],
      ctaTitle: "Have a piece in mind?",
      ctaBody:
        "Send the drawing, the sample or just the dimensions. We will come back with a price and a lead time.",
    },
    collections: {
      title: "Collections",
      lede: "Everything we make, grouped by what it is for.",
      viewAll: "View range",
      itemCount: (n: number) => (n === 1 ? "1 product" : `${n} products`),
    },
    product: {
      backTo: "Back to",
      colours: "Colourways",
      colourNote:
        "Shown in our stock colours. Any colour can be matched to a swatch.",
      specs: "Specification",
      enquire: "Request a quote for this piece",
      enquireNote:
        "Tell us your quantity and branding and we will come back with a unit price and lead time.",
      related: "Elsewhere in this range",
      gallery: "Gallery",
    },
    about: {
      title: "About Cara",
      lede: "We are a leather workshop that works under other people's names.",
      body: [
        "Cara makes leather goods for jewellers, brand owners and companies that give things away for a living. Most of what leaves the workshop carries someone else's mark on the lid, which is the point.",
        "The work is split across four ranges — jewellery packaging, corporate gifts, men's bags and small leather goods — but it is the same workshop, the same leather store and the same people finishing the edges on all of them. That is why a ring box and a messenger bag can be ordered in the same leather and arrive matching.",
        "We are set up for repeat production rather than one-offs. An order starts with a sample you can hold and mark up; once you approve it, that sample becomes the standard every later unit is checked against. Reorder in a year and you get the same piece, not a new interpretation of it.",
      ],
      valuesTitle: "How we work",
      values: [
        {
          title: "One approved sample",
          body: "Nothing goes into production until you have held it and signed it off. That sample stays with us and every unit is checked against it.",
        },
        {
          title: "Hand-finished edges",
          body: "Edges are painted and burnished by hand, not folded and glued. It takes longer and it is the first thing a buyer notices.",
        },
        {
          title: "Your mark, not ours",
          body: "Cara does not appear on anything we make for you unless you ask for it. The lid is yours.",
        },
      ],
    },
    contact: {
      title: "Request a quote",
      lede: "Tell us what you need. Include quantity and branding if you know them — if you do not, say so and we will work it out together.",
      name: "Name",
      company: "Company",
      email: "Email",
      phone: "Phone",
      country: "Country",
      interest: "Interested in",
      quantity: "Estimated quantity",
      message: "Details",
      messagePlaceholder:
        "Dimensions, leather, lining, branding, deadline — whatever you have.",
      submit: "Send enquiry",
      selectPrompt: "Select a range",
      generalEnquiry: "General enquiry",
      required: "Required",
      hours: "Hours",
      directTitle: "Or reach us directly",
      sending: "Sending…",
      sent: "Thank you — your enquiry is on its way. We reply within one working day.",
      error:
        "That did not send. Please email us directly at info@cara-leather.com, or message us on WhatsApp.",
      whatsappCta: "Message us on WhatsApp",
      sendAnother: "Send another enquiry",
    },
    footer: {
      tagline:
        "Leather goods manufacturer. Jewellery packaging, corporate gifts, bags and small leather goods.",
      collections: "Collections",
      company: "Company",
      getInTouch: "Get in touch",
      rights: "All rights reserved.",
    },
    contactInfo: {
      addressLabel: "Office",
      address: "15 Moussa Ebn Nosseir St., Nozha, Cairo",
      whatsappLabel: "WhatsApp",
      hours: "Sun–Thu, 9:00–18:00",
    },
  },
  ar: {
    langName: "العربية",
    otherLangName: "English",
    brand: "كارا",
    whatsappGreeting: "مرحبًا كارا — أريد عرض سعر لـ",
    brandLine: "منتجات جلدية",
    maison: {
      stockLeathers: "الجلود المتوفرة",
      stockLine: "عشرون لونًا في المخزن. وأي لون آخر يُطابَق حسب عيّنة.",
      range: "مجموعة",
    },
    nav: {
      collections: "المجموعات",
      capabilities: "الإمكانات",
      about: "عن كارا",
      contact: "تواصل",
      enquire: "اطلب عرض سعر",
    },
    home: {
      eyebrow: "مصنّع منتجات جلدية",
      title: "جلد يحمل اسم غيرنا.",
      lede: "تصنع كارا علب المجوهرات والهدايا المؤسسية والحقائب والمنتجات الجلدية الصغيرة للعلامات التي تضع ختمها على الغطاء. قصّ وخياطة وتبطين وتشطيب حسب مواصفاتك.",
      ctaPrimary: "تصفّح الكتالوج",
      ctaSecondary: "ابدأ طلبك",
      statsTitle: "مبني على مقاس طلبك",
      stats: [
        { value: "٢٥٠", label: "الحد الأدنى لمعظم المنتجات" },
        { value: "٤–٦", label: "أسابيع من العيّنة إلى التسليم" },
        { value: "+٢٠", label: "لون جلد متوفر" },
        { value: "١٠٠٪", label: "حواف مشطّبة يدويًا" },
      ],
      collectionsTitle: "المجموعات",
      collectionsLede: "أربع مجموعات، من الورشة ذاتها، وكلها قابلة للتخصيص.",
      featuredTitle: "كل ما نصنعه",
      featuredLede:
        "الكتالوج الكامل. كل قطعة أدناه قابلة لتغيير اللون والمقاس والبطانة والعلامة.",
      processTitle: "كيف يسير الطلب",
      processLede: "من أول رسم حتى الشحن. جهة تواصل واحدة طوال الطريق.",
      process: [
        {
          title: "الفكرة والرسم",
          body: "أرسل لنا قطعة أو رسمًا أو علبة منافس. نعود إليك برسم وقائمة جلود وسعر للوحدة حسب الكمية.",
        },
        {
          title: "العيّنة",
          body: "نصنع واحدة. تصلك القطعة الحقيقية بين يديك — الجلد والبطانة ولون الخيط والعلامة — وتضع ملاحظاتك حتى تصبح كما تريد.",
        },
        {
          title: "الإنتاج",
          body: "العيّنة المعتمدة تصبح المعيار. تُفحص كل قطعة مقابلها قبل التغليف.",
        },
        {
          title: "التسليم",
          body: "تُعبّأ وتُوسم حسب مواصفاتك وتُشحن بشروطك. الطلبات المتكررة تعمل على العيّنة المعتمدة نفسها.",
        },
      ],
      customTitle: "التخصيص",
      customLede: "ما يمكن تغييره في كل قطعة.",
      custom: [
        {
          title: "الجلد واللون",
          body: "جلد محبب أو عجل أملس أو شمواه مشمّع، بأي من ألواننا المتوفرة أو مطابقًا لعيّنة ترسلها.",
        },
        {
          title: "البطانة",
          body: "شمواه أو ألياف دقيقة أو قماش، بلون متباين أو مطابق. حشوات مفصّلة على القطعة التي ستحتويها العلبة.",
        },
        {
          title: "العلامة",
          body: "نقش غائر أو رقائق ذهبية أو فضية أو طباعة شاشة أو لوحة معدنية مركّبة في الغطاء.",
        },
        {
          title: "المقاسات",
          body: "أي بُعد في أي علبة قابل للتغيير. أخبرنا بما سيوضع داخلها ونبني الغلاف حوله.",
        },
      ],
      ctaTitle: "لديك قطعة في بالك؟",
      ctaBody: "أرسل الرسم أو العيّنة أو المقاسات فقط. سنعود إليك بالسعر ومدة التنفيذ.",
    },
    collections: {
      title: "المجموعات",
      lede: "كل ما نصنعه، مرتّبًا حسب الغرض.",
      viewAll: "عرض المجموعة",
      itemCount: (n: number) => (n === 1 ? "منتج واحد" : `${n} منتجات`),
    },
    product: {
      backTo: "العودة إلى",
      colours: "الألوان",
      colourNote: "معروضة بألواننا المتوفرة. ويمكن مطابقة أي لون حسب عيّنة.",
      specs: "المواصفات",
      enquire: "اطلب عرض سعر لهذه القطعة",
      enquireNote: "أخبرنا بالكمية والعلامة وسنعود إليك بسعر الوحدة ومدة التنفيذ.",
      related: "من المجموعة ذاتها",
      gallery: "الصور",
    },
    about: {
      title: "عن كارا",
      lede: "ورشة جلود تعمل تحت أسماء الآخرين.",
      body: [
        "تصنع كارا منتجات جلدية لتجار المجوهرات وأصحاب العلامات والشركات التي تقدّم الهدايا كجزء من عملها. معظم ما يخرج من الورشة يحمل ختم غيرنا على الغطاء، وهذا هو المقصود.",
        "يتوزّع العمل على أربع مجموعات — علب المجوهرات والهدايا المؤسسية والحقائب الرجالية والمنتجات الجلدية الصغيرة — لكنها الورشة ذاتها ومخزن الجلود ذاته والأيدي ذاتها التي تشطّب الحواف. لذلك يمكن طلب علبة خاتم وحقيبة كتف بالجلد نفسه فتصل متطابقة.",
        "نحن مهيّأون للإنتاج المتكرر لا للقطع الفردية. يبدأ الطلب بعيّنة تمسكها وتضع ملاحظاتك عليها؛ وبعد اعتمادها تصبح المعيار الذي تُفحص مقابله كل قطعة لاحقة. أعد الطلب بعد سنة فتحصل على القطعة نفسها لا على تفسير جديد لها.",
      ],
      valuesTitle: "طريقتنا في العمل",
      values: [
        {
          title: "عيّنة معتمدة واحدة",
          body: "لا شيء يدخل الإنتاج قبل أن تمسكه وتعتمده. تبقى تلك العيّنة عندنا وتُفحص كل قطعة مقابلها.",
        },
        {
          title: "حواف مشطّبة يدويًا",
          body: "تُدهن الحواف وتُصقل يدويًا لا تُطوى وتُلصق. يستغرق ذلك وقتًا أطول، وهو أول ما يلاحظه المشتري.",
        },
        {
          title: "ختمك لا ختمنا",
          body: "لا يظهر اسم كارا على شيء نصنعه لك إلا إذا طلبت ذلك. الغطاء لك.",
        },
      ],
    },
    contact: {
      title: "اطلب عرض سعر",
      lede: "أخبرنا بما تحتاجه. أضف الكمية والعلامة إن كنت تعرفهما — وإن لم تكن، أخبرنا وسنصل إليهما معًا.",
      name: "الاسم",
      company: "الشركة",
      email: "البريد الإلكتروني",
      phone: "الهاتف",
      country: "الدولة",
      interest: "المجموعة المطلوبة",
      quantity: "الكمية التقديرية",
      message: "التفاصيل",
      messagePlaceholder: "المقاسات، الجلد، البطانة، العلامة، الموعد النهائي — أي معلومة لديك.",
      submit: "إرسال الطلب",
      selectPrompt: "اختر مجموعة",
      generalEnquiry: "استفسار عام",
      required: "مطلوب",
      hours: "ساعات العمل",
      directTitle: "أو تواصل معنا مباشرة",
      sending: "جارٍ الإرسال…",
      sent: "شكرًا لك — وصلنا طلبك. نردّ خلال يوم عمل واحد.",
      error:
        "تعذّر الإرسال. راسلنا مباشرة على info@cara-leather.com أو عبر واتساب.",
      whatsappCta: "راسلنا على واتساب",
      sendAnother: "إرسال طلب آخر",
    },
    footer: {
      tagline:
        "مصنّع منتجات جلدية. علب مجوهرات وهدايا مؤسسية وحقائب ومنتجات جلدية صغيرة.",
      collections: "المجموعات",
      company: "الشركة",
      getInTouch: "تواصل معنا",
      rights: "جميع الحقوق محفوظة.",
    },
    contactInfo: {
      addressLabel: "المكتب",
      address: "١٥ شارع موسى بن نصير، النزهة، القاهرة",
      whatsappLabel: "واتساب",
      hours: "الأحد–الخميس، ٩:٠٠–١٨:٠٠",
    },
  },
} as const;

export type Dict = (typeof dictionaries)["en"];

export const getDict = (lang: Lang): Dict =>
  dictionaries[lang] as unknown as Dict;

/** Narrow a raw route segment to a Lang, 404ing on anything else. */
export function isLang(value: string): value is Lang {
  return (languages as string[]).includes(value);
}

/**
 * Route segments arrive typed as `string`. Only "en" and "ar" are ever
 * generated, so anything else falls back to the default language.
 */
export const toLang = (value: string): Lang => (isLang(value) ? value : "en");
