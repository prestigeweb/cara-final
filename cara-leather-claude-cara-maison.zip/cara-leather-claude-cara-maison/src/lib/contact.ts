/**
 * Contact details for the business, in one place — the enquiry form, the
 * footer, the contact page and the WhatsApp button all read from here.
 */
export const contact = {
  email: "info@cara-leather.com",

  /** As dialled locally in Egypt. */
  whatsappLocal: "0100 668 8790",
  /** E.164 without the +, which is what wa.me expects. */
  whatsappE164: "201006688790",
  /** For display next to an international audience. */
  whatsappDisplay: "+20 100 668 8790",
} as const;

/** A wa.me link, optionally opening with a message already typed. */
export const whatsAppLink = (message?: string) =>
  `https://wa.me/${contact.whatsappE164}` +
  (message ? `?text=${encodeURIComponent(message)}` : "");
