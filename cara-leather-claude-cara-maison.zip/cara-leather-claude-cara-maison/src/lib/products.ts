export type Lang = "en" | "ar";

export type Localized = Record<Lang, string>;

export type Swatch = {
  /** Colour name shown to the visitor. */
  name: Localized;
  /** Approximate hex of the leather, used for the swatch dot. */
  hex: string;
};

export type Product = {
  slug: string;
  category: CategorySlug;
  name: Localized;
  /** One-line summary used on cards. */
  tagline: Localized;
  description: Localized;
  /** Number of source images available in /public/products. */
  images: number;
  swatches: Swatch[];
  specs: { label: Localized; value: Localized }[];
  /** Featured on the home page. */
  featured?: boolean;
};

export type CategorySlug =
  | "jewellery-packaging"
  | "corporate-gifts"
  | "lady-bags"
  | "mens-bags"
  | "school"
  | "wallets";

export type Category = {
  slug: CategorySlug;
  name: Localized;
  blurb: Localized;
  /** Product slug whose first image represents the category. */
  cover: string;
};

export const categories: Category[] = [
  {
    slug: "jewellery-packaging",
    name: { en: "Jewellery Packaging", ar: "علب المجوهرات" },
    blurb: {
      en: "Ring, pendant, bracelet and bangle boxes built to hold a piece the way a showroom would.",
      ar: "علب للخواتم والقلائد والأساور والغوايش، مصممة لعرض القطعة كما يعرضها صالة العرض.",
    },
    cover: "pebbled-ring-box",
  },
  {
    slug: "corporate-gifts",
    name: { en: "Corporate Gifts", ar: "الهدايا المؤسسية" },
    blurb: {
      en: "Presentation and keepsake boxes for launches, milestones and executive gifting.",
      ar: "علب تقديم وحفظ للإطلاقات والمناسبات والهدايا التنفيذية.",
    },
    cover: "heritage-trunk-gift-box",
  },
  {
    slug: "lady-bags",
    name: { en: "Lady Bags", ar: "حقائب نسائية" },
    blurb: {
      en: "Quilted backpacks and drawstring bucket bags, in smooth calf and hair-on hide.",
      ar: "حقائب ظهر مبطّنة وحقائب برباط، من جلد العجل الأملس والجلد بالشعر.",
    },
    cover: "quilted-leather-backpack",
  },
  {
    slug: "mens-bags",
    name: { en: "Men's Bags", ar: "حقائب رجالية" },
    blurb: {
      en: "Everyday carry in full-grain leather — crossbody bags and laptop backpacks.",
      ar: "حقائب يومية من الجلد الطبيعي الكامل — حقائب كتف وحقائب ظهر للحاسوب.",
    },
    cover: "crossbody-messenger-bag",
  },
  {
    slug: "school",
    name: { en: "School", ar: "مستلزمات مدرسية" },
    blurb: {
      en: "Backpacks built to last a school year, and leather folders for the desk.",
      ar: "حقائب مصمّمة لتدوم عامًا دراسيًا، وملفات جلدية للمكتب.",
    },
    cover: "school-backpack",
  },
  {
    slug: "wallets",
    name: { en: "Wallets & Card Holders", ar: "محافظ وحوامل بطاقات" },
    blurb: {
      en: "Slim card holders and classic bifolds, blind-embossed with your mark.",
      ar: "حوامل بطاقات نحيفة ومحافظ كلاسيكية، مع نقش شعارك الغائر.",
    },
    cover: "classic-bifold-wallet",
  },
];

const spec = (en: string, ar: string, ven: string, var_: string) => ({
  label: { en, ar },
  value: { en: ven, ar: var_ },
});

export const products: Product[] = [
  // ---------------------------------------------------------------- jewellery
  {
    slug: "pebbled-ring-box",
    category: "jewellery-packaging",
    name: { en: "Pebbled Ring Box", ar: "علبة خاتم محببة" },
    tagline: {
      en: "Hinged ring box in pebble-grain leather with a suede ring bed.",
      ar: "علبة خاتم بمفصلة من الجلد المحبب مع قاعدة من الشمواه.",
    },
    description: {
      en: "A compact hinged case for solitaires and bands. The pebble-grain shell is wrapped by hand over a rigid core, contrast-stitched along every edge, and lined in warm suede with a sprung ring slot that grips the band without marking it.",
      ar: "علبة مفصلية صغيرة للخواتم المنفردة والحلقات. يُلف الغلاف المحبب يدويًا على هيكل صلب، مع خياطة متباينة على كل حافة، وبطانة من الشمواه الدافئ وشق مرن يثبّت الخاتم دون أن يخدشه.",
    },
    images: 2,
    swatches: [
      { name: { en: "Black", ar: "أسود" }, hex: "#2b2b2b" },
      { name: { en: "Navy", ar: "كحلي" }, hex: "#23314c" },
      { name: { en: "Forest Green", ar: "أخضر غامق" }, hex: "#20452f" },
      { name: { en: "Burgundy", ar: "عنابي" }, hex: "#5c2130" },
    ],
    specs: [
      spec("Closure", "الإغلاق", "Hinged lid, snap catch", "غطاء بمفصلة وقفل ضاغط"),
      spec("Lining", "البطانة", "Suede, ring slot insert", "شمواه مع حشوة شق الخاتم"),
      spec("Branding", "العلامة", "Blind deboss or foil, lid or interior", "نقش غائر أو رقائق على الغطاء أو الداخل"),
      spec("Minimum order", "الحد الأدنى", "500 units per colourway", "٥٠٠ قطعة لكل لون"),
    ],
    featured: true,
  },
  {
    slug: "pendant-presentation-box",
    category: "jewellery-packaging",
    name: { en: "Pendant Presentation Box", ar: "علبة تقديم القلائد" },
    tagline: {
      en: "Square pendant case with a ribbon keeper and full suede interior.",
      ar: "علبة مربعة للقلائد مع شريط تثبيت وبطانة شمواه كاملة.",
    },
    description: {
      en: "Sized for pendants, studs and short chains. A satin ribbon keeper holds the chain at the crown while the pad below seats the pendant flat, so the piece reads as one line when the lid opens.",
      ar: "بمقاس مناسب للقلائد والأقراط والسلاسل القصيرة. يثبّت شريط الساتان السلسلة من الأعلى بينما تستقر القطعة مسطحة على الوسادة، فتبدو متناسقة عند فتح الغطاء.",
    },
    images: 2,
    swatches: [
      { name: { en: "Forest Green", ar: "أخضر غامق" }, hex: "#1f5138" },
      { name: { en: "Ivory", ar: "عاجي" }, hex: "#e6e0d4" },
      { name: { en: "Blush", ar: "وردي فاتح" }, hex: "#e0aeb0" },
      { name: { en: "Slate Grey", ar: "رمادي" }, hex: "#565049" },
    ],
    specs: [
      spec("Closure", "الإغلاق", "Hinged lid, snap catch", "غطاء بمفصلة وقفل ضاغط"),
      spec("Lining", "البطانة", "Suede pad with ribbon keeper", "وسادة شمواه مع شريط تثبيت"),
      spec("Branding", "العلامة", "Blind deboss or foil", "نقش غائر أو رقائق"),
      spec("Minimum order", "الحد الأدنى", "500 units per colourway", "٥٠٠ قطعة لكل لون"),
    ],
    featured: true,
  },
  {
    slug: "bracelet-presentation-box",
    category: "jewellery-packaging",
    name: { en: "Bracelet Presentation Box", ar: "علبة تقديم الأساور" },
    tagline: {
      en: "Elongated case with twin ribbon anchors for bracelets and tennis lines.",
      ar: "علبة مستطيلة بشريطين لتثبيت الأساور والسلاسل.",
    },
    description: {
      en: "A long-format case for bracelets, watches and tennis lines. Twin ribbon anchors hold the piece open across the pad instead of letting it coil, and the deep lid clears a raised clasp.",
      ar: "علبة طويلة للأساور والساعات والسلاسل. يثبّت الشريطان القطعة ممدودة على الوسادة بدل أن تتلوّى، والغطاء العميق يتسع للإبزيم البارز.",
    },
    images: 2,
    swatches: [
      { name: { en: "Cream", ar: "كريمي" }, hex: "#ded3c4" },
      { name: { en: "Navy", ar: "كحلي" }, hex: "#2a3a56" },
      { name: { en: "Tan", ar: "بني فاتح" }, hex: "#8a5c3b" },
      { name: { en: "Espresso", ar: "بني داكن" }, hex: "#3d342e" },
    ],
    specs: [
      spec("Closure", "الإغلاق", "Hinged lid, snap catch", "غطاء بمفصلة وقفل ضاغط"),
      spec("Lining", "البطانة", "Suede pad, twin ribbon anchors", "وسادة شمواه مع شريطي تثبيت"),
      spec("Stitching", "الخياطة", "Contrast saddle stitch", "خياطة سرج متباينة"),
      spec("Minimum order", "الحد الأدنى", "500 units per colourway", "٥٠٠ قطعة لكل لون"),
    ],
  },
  {
    slug: "bangle-presentation-box",
    category: "jewellery-packaging",
    name: { en: "Bangle Presentation Box", ar: "علبة تقديم الغوايش" },
    tagline: {
      en: "Deep square case with a sprung cuff holder for bangles and cuffs.",
      ar: "علبة مربعة عميقة مع حامل مرن للغوايش والأساور الصلبة.",
    },
    description: {
      en: "Built around a sprung suede holder that opens to take a rigid bangle or cuff and closes around it, so the piece sits proud of the pad rather than lying flat. Deeper walls than the ring box, same shell and stitch.",
      ar: "مبنية حول حامل شمواه مرن ينفتح ليستقبل الغويشة أو السوار الصلب ثم ينغلق حوله، فتبقى القطعة بارزة بدل أن تستلقي. جدران أعمق من علبة الخاتم بالغلاف والخياطة ذاتها.",
    },
    images: 2,
    swatches: [
      { name: { en: "Cream", ar: "كريمي" }, hex: "#e2d7c6" },
      { name: { en: "Blush", ar: "وردي فاتح" }, hex: "#d99a95" },
      { name: { en: "Burgundy", ar: "عنابي" }, hex: "#6a2b34" },
      { name: { en: "Navy", ar: "كحلي" }, hex: "#2b3a57" },
    ],
    specs: [
      spec("Closure", "الإغلاق", "Hinged lid, snap catch", "غطاء بمفصلة وقفل ضاغط"),
      spec("Lining", "البطانة", "Suede with sprung cuff holder", "شمواه مع حامل مرن"),
      spec("Branding", "العلامة", "Blind deboss, lid centre", "نقش غائر في وسط الغطاء"),
      spec("Minimum order", "الحد الأدنى", "500 units per colourway", "٥٠٠ قطعة لكل لون"),
    ],
  },
  {
    slug: "double-ring-box",
    category: "jewellery-packaging",
    name: { en: "Double Ring Box", ar: "علبة خاتمين" },
    tagline: {
      en: "Twin-slot box for an engagement ring and its band, side by side.",
      ar: "علبة بشقّين لخاتم الخطوبة ودبلته جنبًا إلى جنب.",
    },
    description: {
      en: "A wider case than the single ring box, with two sprung slots running side by side so an engagement ring and its wedding band present together rather than stacked. The lid clears a raised solitaire.",
      ar: "علبة أعرض من علبة الخاتم المفرد، بشقّين مرنين متجاورين ليُعرض خاتم الخطوبة ودبلته معًا لا فوق بعضهما. والغطاء يتسع للفص البارز.",
    },
    images: 2,
    swatches: [{ name: { en: "Cream", ar: "كريمي" }, hex: "#e0d7c6" }],
    specs: [
      spec("Closure", "الإغلاق", "Hinged lid, snap catch", "غطاء بمفصلة وقفل ضاغط"),
      spec("Lining", "البطانة", "Suede, twin ring slots", "شمواه مع شقّين للخاتم"),
      spec("Branding", "العلامة", "Blind deboss or foil", "نقش غائر أو رقائق"),
      spec("Minimum order", "الحد الأدنى", "500 units per colourway", "٥٠٠ قطعة لكل لون"),
    ],
  },
  // ----------------------------------------------------------- corporate gifts
  {
    slug: "heritage-trunk-gift-box",
    category: "corporate-gifts",
    name: { en: "Heritage Trunk Gift Box", ar: "علبة هدايا الصندوق التراثي" },
    tagline: {
      en: "Large trunk-style box in waxed suede with twin leather straps.",
      ar: "علبة كبيرة بأسلوب الصندوق من الشمواه المشمّع مع حزامين جلديين.",
    },
    description: {
      en: "The largest box in the range, finished in waxed suede that shades under the hand. Twin leather straps run over the lid into hidden magnets, and the interior is a single undivided bay — dividers, foam beds or fabric trays are cut to your contents.",
      ar: "أكبر علبة في المجموعة، بتشطيب من الشمواه المشمّع الذي يتدرّج لونه تحت اليد. يمتد حزامان جلديان فوق الغطاء إلى مغانط مخفية، والداخل حيّز واحد غير مقسّم — تُفصَّل الفواصل أو الحشوات أو الأدراج حسب محتوياتك.",
    },
    images: 2,
    swatches: [{ name: { en: "Vintage Brown", ar: "بني عتيق" }, hex: "#7c5336" }],
    specs: [
      spec("Closure", "الإغلاق", "Twin straps over hidden magnets", "حزامان فوق مغانط مخفية"),
      spec("Interior", "الداخل", "Open bay, made-to-fit inserts", "حيّز مفتوح مع حشوات مفصّلة"),
      spec("Branding", "العلامة", "Deboss, foil or metal plate", "نقش أو رقائق أو لوحة معدنية"),
      spec("Minimum order", "الحد الأدنى", "250 units", "٢٥٠ قطعة"),
    ],
    featured: true,
  },
  {
    slug: "magnetic-presentation-box",
    category: "corporate-gifts",
    name: { en: "Magnetic Presentation Box", ar: "علبة تقديم مغناطيسية" },
    tagline: {
      en: "Square black box with brass studs and a fold-back suede lid.",
      ar: "علبة سوداء مربعة بمسامير نحاسية وغطاء شمواه قابل للطي.",
    },
    description: {
      en: "A flat-profile box for documents, certificates, keys or a watch. The lid folds all the way back on itself and holds there on brass studs, which keeps the box open on a desk without a hand on it.",
      ar: "علبة منخفضة الارتفاع للوثائق والشهادات والمفاتيح أو الساعات. ينطوي الغطاء للخلف بالكامل ويثبت على مسامير نحاسية، فتبقى العلبة مفتوحة على المكتب دون إمساكها.",
    },
    images: 2,
    swatches: [{ name: { en: "Black", ar: "أسود" }, hex: "#1c1c1c" }],
    specs: [
      spec("Closure", "الإغلاق", "Brass stud, fold-back lid", "مسمار نحاسي وغطاء قابل للطي"),
      spec("Interior", "الداخل", "Full suede, open tray", "شمواه كامل مع درج مفتوح"),
      spec("Branding", "العلامة", "Blind deboss or foil on lid", "نقش غائر أو رقائق على الغطاء"),
      spec("Minimum order", "الحد الأدنى", "250 units", "٢٥٠ قطعة"),
    ],
  },
  {
    slug: "strap-close-keepsake-box",
    category: "corporate-gifts",
    name: { en: "Strap-Close Keepsake Box", ar: "علبة حفظ بحزام" },
    tagline: {
      en: "Tan keepsake box with a single strap tab and a lift-out suede tray.",
      ar: "علبة حفظ بلون بني فاتح مع لسان حزام ودرج شمواه قابل للرفع.",
    },
    description: {
      en: "Smooth tan leather over a rigid core, closed by a single strap tab and a concealed magnet. Inside, a lift-out suede tray sits above a lower bay — the tray takes the gift, the bay takes the card, cable or paperwork.",
      ar: "جلد بني فاتح أملس على هيكل صلب، يُغلق بلسان حزام ومغناطيس مخفي. في الداخل درج شمواه قابل للرفع فوق حيّز سفلي — الدرج للهدية، والحيّز للبطاقة أو السلك أو الأوراق.",
    },
    images: 2,
    swatches: [{ name: { en: "Tan", ar: "بني فاتح" }, hex: "#c07f43" }],
    specs: [
      spec("Closure", "الإغلاق", "Strap tab, concealed magnet", "لسان حزام مع مغناطيس مخفي"),
      spec("Interior", "الداخل", "Lift-out suede tray over lower bay", "درج شمواه قابل للرفع فوق حيّز سفلي"),
      spec("Branding", "العلامة", "Deboss or foil", "نقش أو رقائق"),
      spec("Minimum order", "الحد الأدنى", "250 units", "٢٥٠ قطعة"),
    ],
  },
  // --------------------------------------------------------------- men's bags
  {
    slug: "crossbody-messenger-bag",
    category: "mens-bags",
    name: { en: "Crossbody Messenger Bag", ar: "حقيبة كتف كروس" },
    tagline: {
      en: "Flap-over crossbody in pebble-grain leather, five colourways.",
      ar: "حقيبة كتف بغطاء من الجلد المحبب، بخمسة ألوان.",
    },
    description: {
      en: "A flap-over crossbody cut for a tablet, a folio and the things that travel with them. The zip on the face opens to a flat pocket you can reach without lifting the flap, and the webbed strap adjusts through a leather-cased slider.",
      ar: "حقيبة كتف بغطاء أمامي تتسع للوحي وملف وما يرافقهما. يفتح السحاب الأمامي على جيب مسطّح يمكن الوصول إليه دون رفع الغطاء، ويُضبط الحزام عبر مشبك مغلّف بالجلد.",
    },
    images: 2,
    swatches: [
      { name: { en: "Espresso", ar: "بني داكن" }, hex: "#4a3a30" },
      { name: { en: "Black", ar: "أسود" }, hex: "#232323" },
      { name: { en: "Navy", ar: "كحلي" }, hex: "#2c3c57" },
      { name: { en: "Burgundy", ar: "عنابي" }, hex: "#6b2a38" },
      { name: { en: "Tan", ar: "بني فاتح" }, hex: "#b9753c" },
    ],
    specs: [
      spec("Leather", "الجلد", "Full-grain pebble", "جلد طبيعي كامل محبب"),
      spec("Strap", "الحزام", "Adjustable, leather-cased slider", "قابل للضبط بمشبك مغلّف بالجلد"),
      spec("Fits", "يتسع لـ", "Tablet, A4 folio", "لوحي وملف A4"),
      spec("Minimum order", "الحد الأدنى", "100 units per colourway", "١٠٠ قطعة لكل لون"),
    ],
    featured: true,
  },
  {
    slug: "leather-laptop-backpack",
    category: "mens-bags",
    name: { en: "Leather Laptop Backpack", ar: "حقيبة ظهر جلدية للحاسوب" },
    tagline: {
      en: "Structured commuter backpack with a padded laptop wall.",
      ar: "حقيبة ظهر مهيكلة للتنقل مع جدار مبطّن للحاسوب.",
    },
    description: {
      en: "A structured commuter pack that holds its shape empty. The laptop wall is padded and suspended clear of the base, the top handle is rolled and stitched rather than riveted, and the front pocket closes under two buckled straps with a side zip for quick reach.",
      ar: "حقيبة مهيكلة تحافظ على شكلها وهي فارغة. جدار الحاسوب مبطّن ومعلّق بعيدًا عن القاعدة، والمقبض العلوي ملفوف ومخيط لا مثبّت بمسامير، ويُغلق الجيب الأمامي تحت حزامين بإبزيم مع سحاب جانبي للوصول السريع.",
    },
    images: 2,
    swatches: [{ name: { en: "Black", ar: "أسود" }, hex: "#1f1f1f" }],
    specs: [
      spec("Leather", "الجلد", "Full-grain, waxed finish", "جلد طبيعي كامل بتشطيب مشمّع"),
      spec("Laptop", "الحاسوب", "Padded wall, up to 16\"", "جدار مبطّن حتى ١٦ بوصة"),
      spec("Hardware", "الإكسسوارات", "Antique brass buckles", "أبازيم نحاسية عتيقة"),
      spec("Minimum order", "الحد الأدنى", "100 units", "١٠٠ قطعة"),
    ],
  },
  // --------------------------------------------------------------- lady bags
  {
    slug: "quilted-leather-backpack",
    category: "lady-bags",
    name: { en: "Quilted Leather Backpack", ar: "حقيبة ظهر جلدية مبطّنة" },
    tagline: {
      en: "Diamond-quilted backpack with gold hardware, in four colourways.",
      ar: "حقيبة ظهر بتبطين معيّن وإكسسوارات ذهبية، بأربعة ألوان.",
    },
    description: {
      en: "A compact backpack in smooth calf, quilted on a diamond and topped with a rolled grab handle. The zipped front pocket sits proud of the body so it stays reachable with the bag on, and the straps drop to shoulder-bag length.",
      ar: "حقيبة ظهر صغيرة من جلد العجل الأملس، مبطّنة بنقش معيّن وبمقبض علوي ملفوف. الجيب الأمامي بسحاب بارز عن الجسم ليبقى في المتناول والحقيبة على الظهر، ويمتد الحزامان ليصلا إلى طول حقيبة الكتف.",
    },
    images: 2,
    swatches: [
      { name: { en: "Chocolate", ar: "بني داكن" }, hex: "#5a3225" },
      { name: { en: "Tan", ar: "بني فاتح" }, hex: "#b5713c" },
      { name: { en: "Ivory", ar: "عاجي" }, hex: "#e9e4d9" },
      { name: { en: "Black", ar: "أسود" }, hex: "#232323" },
    ],
    specs: [
      spec("Leather", "الجلد", "Smooth calf, diamond quilted", "جلد عجل أملس بتبطين معيّن"),
      spec("Hardware", "الإكسسوارات", "Polished gold", "ذهبي مصقول"),
      spec("Straps", "الأحزمة", "Adjustable to shoulder length", "قابلة للضبط حتى طول الكتف"),
      spec("Minimum order", "الحد الأدنى", "100 units per colourway", "١٠٠ قطعة لكل لون"),
    ],
    featured: true,
  },
  {
    slug: "drawstring-bucket-bag",
    category: "lady-bags",
    name: { en: "Drawstring Bucket Bag", ar: "حقيبة دلو برباط" },
    tagline: {
      en: "Bucket bag in hair-on hide and smooth leather, six combinations.",
      ar: "حقيبة دلو من الجلد بالشعر والجلد الأملس، بستة تركيبات.",
    },
    description: {
      en: "A drawstring bucket in two materials: hair-on hide for the body, smooth leather for the base, strap and tie. No two hides mark the same way, so every bag in the hair-on colourways is its own piece. Plain calf versions are available where a uniform run is needed.",
      ar: "حقيبة دلو برباط من مادتين: جلد بالشعر للجسم، وجلد أملس للقاعدة والحزام والرباط. لا يتطابق جلدان في العلامات، فكل حقيبة بألوان الشعر قطعة فريدة. وتتوفر نسخ من جلد العجل السادة عند الحاجة إلى تشغيلة متطابقة.",
    },
    images: 2,
    swatches: [
      { name: { en: "Cowhide & Tan", ar: "جلد بقري وبني فاتح" }, hex: "#8a5a3a" },
      { name: { en: "Cowhide & Black", ar: "جلد بقري وأسود" }, hex: "#3b332e" },
      { name: { en: "Black & Tan", ar: "أسود وبني فاتح" }, hex: "#262220" },
      { name: { en: "Tan & Black", ar: "بني فاتح وأسود" }, hex: "#b07542" },
      { name: { en: "All Black", ar: "أسود بالكامل" }, hex: "#1f1d1c" },
      { name: { en: "Sand & Tan", ar: "رملي وبني فاتح" }, hex: "#cbb389" },
    ],
    specs: [
      spec("Leather", "الجلد", "Hair-on hide with smooth calf trim", "جلد بالشعر مع حواف من جلد العجل"),
      spec("Closure", "الإغلاق", "Leather drawstring", "رباط جلدي"),
      spec("Strap", "الحزام", "Detachable crossbody", "حزام كتف قابل للفصل"),
      spec("Minimum order", "الحد الأدنى", "100 units per colourway", "١٠٠ قطعة لكل لون"),
    ],
  },
  // ------------------------------------------------------------------ school
  {
    slug: "school-backpack",
    category: "school",
    name: { en: "School Backpack", ar: "حقيبة ظهر مدرسية" },
    tagline: {
      en: "Hard-wearing school pack in five colours, built for a full year.",
      ar: "حقيبة مدرسية متينة بخمسة ألوان، مصمّمة لعام كامل.",
    },
    description: {
      en: "Water-resistant fabric over a padded back panel, with a curved front zip that opens wide enough to find a pencil case without unpacking. Seams at the strap roots are bar-tacked, which is where a school bag fails first.",
      ar: "قماش مقاوم للماء على ظهر مبطّن، مع سحاب أمامي منحنٍ يفتح بما يكفي للعثور على المقلمة دون إفراغ الحقيبة. خياطة جذور الأحزمة مقوّاة، وهي أول ما يتلف في الحقيبة المدرسية.",
    },
    images: 2,
    swatches: [
      { name: { en: "Red", ar: "أحمر" }, hex: "#d5332e" },
      { name: { en: "Pink", ar: "وردي" }, hex: "#e0489a" },
      { name: { en: "Turquoise", ar: "فيروزي" }, hex: "#1fa9c4" },
      { name: { en: "Green", ar: "أخضر" }, hex: "#1f9e63" },
      { name: { en: "Black", ar: "أسود" }, hex: "#26262a" },
    ],
    specs: [
      spec("Material", "الخامة", "Water-resistant polyester", "بوليستر مقاوم للماء"),
      spec("Back", "الظهر", "Padded panel, padded straps", "لوح مبطّن وأحزمة مبطّنة"),
      spec("Branding", "العلامة", "Screen print or woven label", "طباعة شاشة أو ليبل منسوج"),
      spec("Minimum order", "الحد الأدنى", "300 units per colourway", "٣٠٠ قطعة لكل لون"),
    ],
    featured: true,
  },
  {
    slug: "everyday-school-backpack",
    category: "school",
    name: { en: "Everyday School Backpack", ar: "حقيبة ظهر مدرسية يومية" },
    tagline: {
      en: "Flat-front pack with a side bottle pocket and a wide front compartment.",
      ar: "حقيبة بواجهة مسطّحة وجيب جانبي للزجاجة وجيب أمامي واسع.",
    },
    description: {
      en: "A simpler shape than the zip-front pack: one deep main compartment, a full-width front pocket for a tablet or a notebook, and an elasticated side pocket sized for a bottle. Any colour on request — the photograph shows the stock green.",
      ar: "شكل أبسط من الحقيبة ذات السحاب الأمامي: جيب رئيسي عميق، وجيب أمامي بعرض الحقيبة يتسع للوحي أو الكرّاس، وجيب جانبي مطّاطي بمقاس الزجاجة. أي لون عند الطلب — والصورة تُظهر الأخضر المتوفر.",
    },
    images: 2,
    swatches: [{ name: { en: "Green", ar: "أخضر" }, hex: "#1f9e63" }],
    specs: [
      spec("Material", "الخامة", "Water-resistant polyester", "بوليستر مقاوم للماء"),
      spec("Pockets", "الجيوب", "Front compartment, side bottle pocket", "جيب أمامي وجيب جانبي للزجاجة"),
      spec("Colour", "اللون", "Any colour to order", "أي لون حسب الطلب"),
      spec("Minimum order", "الحد الأدنى", "300 units per colourway", "٣٠٠ قطعة لكل لون"),
    ],
  },
  {
    slug: "leather-document-folder",
    category: "school",
    name: { en: "Leather Document Folder", ar: "ملف وثائق جلدي" },
    tagline: {
      en: "Slipcase folder for A4 papers and certificates, in four colours.",
      ar: "ملف بغلاف جلدي لأوراق A4 والشهادات، بأربعة ألوان.",
    },
    description: {
      en: "A rigid folder wrapped in smooth leather, with interior corner retainers that hold a certificate flat without adhesive. Used for diplomas, award presentations and signing copies; blind-debossed or foiled on the face.",
      ar: "ملف صلب مغلّف بجلد أملس، مع زوايا داخلية تثبّت الشهادة مسطّحة دون لاصق. يُستخدم للشهادات والتكريمات ونسخ التوقيع؛ مع نقش غائر أو رقائق على الوجه.",
    },
    images: 2,
    swatches: [
      { name: { en: "Burgundy", ar: "عنابي" }, hex: "#6d1f2c" },
      { name: { en: "Forest Green", ar: "أخضر غامق" }, hex: "#1c4a32" },
      { name: { en: "Brown", ar: "بني" }, hex: "#6f4227" },
      { name: { en: "Navy", ar: "كحلي" }, hex: "#23355c" },
    ],
    specs: [
      spec("Size", "المقاس", "Fits A4", "يتسع لمقاس A4"),
      spec("Interior", "الداخل", "Corner retainers", "زوايا تثبيت"),
      spec("Branding", "العلامة", "Blind deboss or hot foil", "نقش غائر أو رقائق ساخنة"),
      spec("Minimum order", "الحد الأدنى", "250 units per colourway", "٢٥٠ قطعة لكل لون"),
    ],
  },
  // ----------------------------------------------------------------- wallets
  {
    slug: "classic-bifold-wallet",
    category: "wallets",
    name: { en: "Classic Bifold Wallet", ar: "محفظة كلاسيكية بطية" },
    tagline: {
      en: "Eight-card bifold with an ID window, blind-embossed on the face.",
      ar: "محفظة بطية لثماني بطاقات مع نافذة هوية ونقش غائر على الوجه.",
    },
    description: {
      en: "The house bifold: eight card slots, twin note sleeves and a clear ID window on a fold-out leaf. Edges are painted and burnished rather than turned, which keeps the closed wallet thin enough for a jacket pocket.",
      ar: "المحفظة الأساسية: ثمانية شقوق للبطاقات، وجيبان للأوراق النقدية، ونافذة هوية شفافة على ورقة قابلة للفتح. الحواف مدهونة ومصقولة لا مطوية، ما يبقي المحفظة نحيفة بما يكفي لجيب السترة.",
    },
    images: 2,
    swatches: [
      { name: { en: "Black", ar: "أسود" }, hex: "#1e1e1e" },
      { name: { en: "Espresso", ar: "بني داكن" }, hex: "#4a2f23" },
      { name: { en: "Tan", ar: "بني فاتح" }, hex: "#b5763f" },
    ],
    specs: [
      spec("Capacity", "السعة", "8 cards, 2 note sleeves, ID window", "٨ بطاقات وجيبان ونافذة هوية"),
      spec("Edges", "الحواف", "Painted and burnished", "مدهونة ومصقولة"),
      spec("Branding", "العلامة", "Blind emboss, face or interior", "نقش غائر على الوجه أو الداخل"),
      spec("Minimum order", "الحد الأدنى", "250 units per colourway", "٢٥٠ قطعة لكل لون"),
    ],
  },
  {
    slug: "slim-card-holder",
    category: "wallets",
    name: { en: "Slim Card Holder", ar: "حامل بطاقات نحيف" },
    tagline: {
      en: "Four-slot card holder with a centre pocket and a thumb notch.",
      ar: "حامل بطاقات بأربعة شقوق وجيب أوسط وفتحة للإبهام.",
    },
    description: {
      en: "Two panels, four slots and a centre pocket, saddle-stitched through the sides only so the card stack has somewhere to go. A thumb notch on each face lifts the outer card without emptying the slot.",
      ar: "لوحان وأربعة شقوق وجيب أوسط، مخيط من الجانبين فقط ليتسع لمجموعة البطاقات. فتحة للإبهام على كل وجه ترفع البطاقة الخارجية دون إفراغ الشق.",
    },
    images: 2,
    swatches: [
      { name: { en: "Navy", ar: "كحلي" }, hex: "#2e3a52" },
      { name: { en: "Forest Green", ar: "أخضر غامق" }, hex: "#1e5138" },
      { name: { en: "Espresso", ar: "بني داكن" }, hex: "#41302a" },
    ],
    specs: [
      spec("Capacity", "السعة", "4 slots, centre pocket", "٤ شقوق وجيب أوسط"),
      spec("Stitching", "الخياطة", "Saddle stitch, sides only", "خياطة سرج من الجانبين"),
      spec("Branding", "العلامة", "Blind emboss", "نقش غائر"),
      spec("Minimum order", "الحد الأدنى", "250 units per colourway", "٢٥٠ قطعة لكل لون"),
    ],
  },
];

export const getCategory = (slug: string) =>
  categories.find((c) => c.slug === slug);

export const getProduct = (slug: string) =>
  products.find((p) => p.slug === slug);

export const productsIn = (slug: CategorySlug) =>
  products.filter((p) => p.category === slug);

/**
 * basePath rewrites next/link and next/image, but not a plain <img src>, so
 * asset URLs carry the prefix themselves.
 */
export const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

export const imageSrc = (
  slug: string,
  index: number,
  size: "sm" | "md" | "lg" = "md",
) => `${basePath}/products/${slug}-${index}-${size}.webp`;
