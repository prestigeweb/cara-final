# Cara Leather

Bilingual (English / Arabic) B2B catalogue site for **Cara**, a leather goods
manufacturer producing jewellery packaging, corporate gifts, men's bags and
small leather goods.

Built with Next.js (App Router) and Tailwind CSS, exported as a fully static
site — no server required to host it.

## Running it

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # static site written to ./out
```

`npm run build` emits `out/`, which can be served by any static host
(Netlify, Vercel, Cloudflare Pages, S3, nginx).

## Structure

```
src/
  app/
    page.tsx                        root → language redirect
    not-found.tsx                   404
    [lang]/
      layout.tsx                    html/dir/fonts per language, header + footer
      page.tsx                      home
      about/                        about
      contact/                      enquiry form
      collections/                  all ranges
      collections/[category]/       one range
      products/[slug]/              product detail
  components/                       header, footer, product card, gallery, form
  i18n/dictionaries.ts              all EN + AR copy
  lib/products.ts                   catalogue data (categories, products, specs)
public/products/                    product imagery, 3 widths each as WebP
```

## Content

**Copy and catalogue data** live in two files:

- `src/i18n/dictionaries.ts` — every string on the site, in both languages.
- `src/lib/products.ts` — categories, products, colourways and specifications.

Both are plain TypeScript with an `{ en, ar }` shape on each translatable
field, so adding a product or changing wording needs no template edits.

### Languages

`en` and `ar` are generated as separate static trees (`/en/…`, `/ar/…`). The
Arabic tree is rendered with `dir="rtl"` and a Noto Sans Arabic face; layout
uses logical properties (`ps-`/`pe-`/`ms-`/`me-`) so it mirrors automatically.
The header's language toggle preserves the current path.

### Imagery

Product photography came from the client's Google Drive as 3600 × 3600 JPEGs.
Each is exported to WebP at three widths (`-sm` 420px, `-md` 800px, `-lg`
1400px) and referenced through `srcset`. The originals are not committed.

To regenerate after adding new photography, resize into
`public/products/<product-slug>-<n>-<size>.webp` and set the product's
`images` count in `src/lib/products.ts`.

## Before launch

- [ ] **Replace the placeholder contact details.** Email, phone, address and
      opening hours are placeholders in `src/i18n/dictionaries.ts` under
      `placeholders`. The contact page and footer both flag this on screen —
      remove `footer.placeholderNote` once real details are in.
- [ ] **Wire up the enquiry form.** With no configuration the form composes the
      enquiry and hands it to the visitor's own mail client. To collect
      submissions properly, set `NEXT_PUBLIC_ENQUIRY_ENDPOINT` to a form
      endpoint (Formspree, Basin, an API route) and the form will POST there
      instead. See `src/components/EnquiryForm.tsx`.
- [ ] **Review the product copy.** Descriptions and specifications were written
      from the photography — minimum order quantities, lead times and materials
      are plausible defaults, not supplied figures. Check them against reality.
- [ ] **Review the Arabic.** The translation is complete but should be read by
      a native speaker before it goes live.
- [ ] Add a real logo mark if one exists (`src/app/icon.svg` is a placeholder
      wordmark initial).
