import type { NextConfig } from "next";

/**
 * Set NEXT_PUBLIC_BASE_PATH when the site is served from a sub-directory
 * rather than a domain root — a GitHub Pages project site, for example, lives
 * under /<repo>/. Leave it unset for a normal root deployment.
 */
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";

const nextConfig: NextConfig = {
  output: "export",
  images: { unoptimized: true },
  trailingSlash: true,
  ...(basePath ? { basePath } : {}),
};

export default nextConfig;
